20.34946^2
11.95508^2

#icc: intraclass correlation
icc_escola <- 414.1005/(414.1005 + 142.9239)
icc_escola

